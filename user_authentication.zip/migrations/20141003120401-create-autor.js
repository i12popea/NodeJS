"use strict";

module.exports = {
  up: function(queryInterface, Sequelize) {
    return queryInterface
      .createTable('Autor', {
        nombre: Sequelize.STRING
      });
  },

  down: function(queryInterface, Sequelize) {
    return queryInterface
      .dropTable('Autor');
  }
};
