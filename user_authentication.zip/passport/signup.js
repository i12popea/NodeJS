var LocalStrategy   = require('passport-local').Strategy;
var User = require('../models/index.js');
var bCrypt = require('bcrypt-nodejs');

module.exports = function(passport){

	/*passport.use('signup', new LocalStrategy({
            passReqToCallback : true // allows us to pass back the entire request to the callback
        },
        function(req, username, password, done) {

            findOrCreateUser = function(){
                // find a user in Mongo with provided username
                User.find({ where: {username:  username }}).success(function(err, user) {
                    // In case of any error, return using the done method
                    if (!user) {
                        done(null, false, { message: 'Unknown user' });
                    } else if (password != user.password) {
                        done(null, false, { message: 'Invalid password'});
                    } else {
                        done(null, user);
                    }
               }).error(function(err){
                   done(err);
               });
        }
    ));*/

passport.use('signup', new LocalStrategy({
      passReqToCallback : true // allows us to pass back the entire request to the callback
  },
  function(req, username, password, done) {
    User.Usuario.find({ where: { username: username }}).then(function(user) {
//console.log("Pasa\n");
      /*if (!err) {
          console.log('Error in SignUp: '+err);
          return done(err);
      }*/
      if (user) {
          console.log('El usuario ya existe: '+username );
          return done(null, false);
      }
      else{
          console.log('El usuario no existe: '+username );
          //if (password != req.param('password2')) {
          if (password != req.body.password2) {
              console.log("Las password no coindicen\n");
              return done(null, false);
          }
          User.Usuario.create({
            username: username,
            pass: createHash(password)
          }).then(function(pass) {
            console.log("Exito\n");
            return done(null, pass);
          });
          //done(null, user);
      }
      /*if (!user) {
        done(null, false, { message: 'Unknown user' });
      } else if (password != user.password) {
        done(null, false, { message: 'Invalid password'});
      } else {
        done(null, user);
      }*/
    }).error(function(err){
      console.log("Error\n");
      done(err);
    });
  }
));

/*        function(req, username, password, done) {

            findOrCreateUser = function(){
                // find a user in Mongo with provided username
                User.find({ where: {username:  username }}, function(err, user) {
                    // In case of any error, return using the done method
                    if (err){
                        console.log('Error in SignUp: '+err);
                        return done(err);
                    }
                    // already exists
                    if (user) {
                        console.log('User already exists with username: '+username);
                        return done(null, false, req.flash('message','User Already Exists'));
                    } else {
                        //if (password == req.param('password2')){} else {return done(null, false, req.flash('message','Las password no coinciden'));}
                        // if there is no user with that email
                        // create the user
                        var newUser = new User();

                        // set the user's local credentials
                        newUser.username = username;
                        newUser.pass = createHash(password);
                       // newUser.email = req.param('email');
                       // newUser.firstName = req.param('firstName');
                       // newUser.lastName = req.param('lastName');

                        // save the user
                        newUser.save(function(err) {
                            if (err){
                                console.log('Error in Saving user: '+err);  
                                throw err;  
                            }
                            console.log('User Registration succesful');    
                            return done(null, newUser);
                        });
                    }
                });
            };
            // Delay the execution of findOrCreateUser and execute the method
            // in the next tick of the event loop
            process.nextTick(findOrCreateUser);
        })
    );*/

    // Generates hash using bCrypt
    var createHash = function(password){
        return bCrypt.hashSync(password, bCrypt.genSaltSync(10), null);
    }

}
