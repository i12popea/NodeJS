var User = require('../models/index.js');
var LocalStrategy   = require('passport-local').Strategy;
var bcrypt = require('bcrypt-nodejs');

module.exports = function(passport){

  /*passport.use(new LocalStrategy(
    function(username, password, done) {
      User.Usuario.findOne({
        where: {
          'username': username
        }
      }).then(function (user) {
        if (user == null) {
          return done(null, false, { message: 'Incorrect credentials.' })
        }

        if (bcrypt.compareSync(password, user.pass)) {
          return done(null, user)
        }
        
        return done(null, false, { message: 'Incorrect credentials.' })
      })
    }
  ))*/

passport.use(new LocalStrategy({
  usernameField: 'usuario',
  passwordField: 'password'
},
  function(username, password, done) {
  // ...
//console.log("funciona\n");
    //User.Usuario.find({ where: { username: username }}).then(function(user) {}
// https://www.google.es/#q=passport+login+strategy+not+called
// https://stackoverflow.com/questions/25218477/passport-local-strategy-not-getting-called-when-email-or-password-empty
    User.Usuario.find({ where: { 
      username: username 
    }}).then(function (user) {
      if(!user) {
        return done(null, false, { message: 'Incorrect credentials.' })
      }
      if(!bcrypt.compareSync(password, user.pass)) {
        return done(null, false, { message: 'Invalid password.' })
      }
      return done(null, user);
    });
  }
));

  /*passport.serializeUser(function(user, done) {
    console.log("Serializer\n");
    done(null, user.id);
  });*/

  /*passport.deserializeUser(function(id, done) {
    User.findById(id, function(err, user) {
      done(err, user);
    });
  });*/

  /*passport.deserializeUser(function(id, done) {
      User.Usuario.findById(id).then(function(user){
          console.log("Deserializer\n");
          done(null, user);
      }).catch(function(e){
          done(e, false);
      });
  });*/

  /*passport.deserializeUser(function(id, done) {
    User.Usuario.find({where: {id: id}}).then(function(user){
      done(null, user);
    }).error(function(err){
      done(err, null);
    });
  });*/

 // login(passport);
 // signup(passport);

  passport.serializeUser(function(user, done) {
    done(null, user.id)
  })

  passport.deserializeUser(function(id, done) {
    User.Usuario.findOne({
      where: {
        'id': id
      }
    }).then(function (user) {
      if (user == null) {
        done(new Error('Wrong user id.'))
      }
      
      done(null, user)
    })
  })

}
