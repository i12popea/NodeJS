"use strict";

module.exports = function(sequelize, DataTypes) {
  var Usuario = sequelize.define("Usuario", {
    username: DataTypes.STRING,
    pass: DataTypes.STRING
  }, {
    classMethods: {
      associate: function(models) {
        Usuario.hasMany(models.Task)
      }
    }
  });

  return Usuario;
};
