var User = require('../models');
var login = require('./login');
var signup = require('./signup');

module.exports = function(passport){

  passport.serializeUser(function(user, done) {
    console.log("Serializer\n");
    done(null, user.id);
  });

  /*passport.deserializeUser(function(id, done) {
    User.findById(id, function(err, user) {
      done(err, user);
    });
  });*/

  passport.deserializeUser(function(id, done) {
      User.Usuario.findById(id).then(function(user){
          console.log("Deserializer\n");
          done(null, user);
      }).catch(function(e){
          done(e, false);
      });
  });

  /*passport.deserializeUser(function(id, done) {
    User.Usuario.find({where: {id: id}}).then(function(user){
      done(null, user);
    }).error(function(err){
      done(err, null);
    });
  });*/

  login(passport);
  signup(passport);

}
