"use strict";

module.exports = function(sequelize, DataTypes) {
  var Autor = sequelize.define("Autor", {
    nombre: DataTypes.STRING
  });

  return Autor;
};
