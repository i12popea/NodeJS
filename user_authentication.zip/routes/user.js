var models  = require('../models');
var express = require('express');
var router  = express.Router();
var signup = require('../passport/signup.js');

function loggedIn(req, res, next) {
	// if user is authenticated in the session, call the next() to call the next request handler 
	// Passport adds this method to request object. A middleware is allowed to add properties to
	// request and response objects
	if (req.user)
	//if (req.isAuthenticated())
		return next();
	// if the user is not authenticated then redirect him to the login page
	res.redirect('/');
}


module.exports = function(passport){

signup(passport);

	// GET login page.
	router.get('/login', function(req, res) {
    	// Display the Login page with any flash message, if any
		res.render('login', { title: 'Express: Login' });
	});

	// Handle Login POST
	router.post('/login', passport.authenticate('local', {
		successRedirect: '/',
		failureRedirect: '/users/login',
		failureFlash : true  
	}));
	/*router.post('/login', passport.authenticate('local'), function(req, res){
  console.log("passport user", req.user);
});*/

	/*router.route('/login')
	    .get(function(req, res) {
		res.render('login', { title: 'Express: Login' });
	    })
	    .post(passport.authenticate('login', {
		successRedirect: '/',
		failureRedirect: '/user/login',
		failureFlash : true
	}));*/

	// GET Registration Page
	router.get('/signup', function(req, res){
		res.render('registrar',{title: 'Express: Crear Usuarios'});
	});

	// Handle Registration POST
	router.post('/signup', passport.authenticate('signup', {
		successRedirect: '/',
		failureRedirect: '/users/signup',
		failureFlash : true  
	}));
	//router.post('/login', signup(passport));

	// GET Home Page
	router.get('/', loggedIn, function(req, res, next){
		res.render('index', { user: req.user });
	});

	// Handle Logout
	router.get('/signout', function(req, res) {
		req.logout();
		res.redirect('/');
	});

	return router;
}




// https://www.google.es/#q=node+js+authentication+is+authenticated
// https://stackoverflow.com/questions/7990890/how-to-implement-login-auth-in-node-js
// https://www.google.es/#q=node+js+check+if+user+is+logged+in



/*app.post('/login',
  passport.authenticate('local', { successRedirect: '/',
                                   failureRedirect: '/login',
                                   failureFlash: true })
);*/













/*router.get('/userLogin', function(req, res) {
  res.render('registrar', { title: 'Express: Crear Usuarios' });
});

router.post('/registrarusuario', function(req, res) {
  models.Usuario.findAll({
    where: {
      username: req.body.usuario
    }
  }).then(function(usuarios) {
    
  });

  models.Usuario.create({
    nombre: req.body.nombre
  }).then(function() {
    res.redirect('/');
  });
});

router.get('/login', function(req, res) {
  res.render('login', { title: 'Express: Login' });
});

router.post('/userlogin', function(req, res) {
  models.Usuario.findAll({
    where: {
      username: req.body.usuario
    }
  }).then(function(usuarios) {
    res.redirect('/');
  });
});

module.exports = router;*/
