var models  = require('../models');
var express = require('express');
var router  = express.Router();
var signup = require('../passport/signup.js');

module.exports = function(passport){

signup(passport);

router.get('/tareas', function(req, res) {
  models.Task.findAll({
    where: { UsuarioId: req.user.id }
  }).then(function(tareas) {
if (req.user)
    res.render('tareas.html', {
      title: 'Express: Tareas',
      Tareas: tareas,
      user: req.user
    });
else
    return res.redirect('/users/login');
  });
});

router.get('/crearTarea', function(req, res) {
if (req.user)
  res.render('crearTarea', { title: 'Express: Crear Tareas', user: req.user });
else
  return res.redirect('/users/login');
});

router.post('/:user_id/tareaCreada', function(req, res) {
if (req.user)
  models.Task.create({
    title: req.body.titulo,
    UsuarioId: req.params.user_id
  }).then(function() {
    res.redirect('/');
  });
else
  return res.redirect('/users/login');
});

router.get('/:user_id/editarTarea', function(req, res) {
if (req.user)
  res.render('editarTarea', { title: 'Express: Editar Tareas', id: req.params.user_id, user: req.user });
else
  return res.redirect('/users/login');
});

	return router;
}

router.post('/:tarea_id/tareaEditada', function(req, res) {
if (req.user)
  models.Task.update(
  {title: req.body.titulo},
  {
    where: {
      id: req.params.tarea_id
    }
  }).then(function() {
    res.redirect('/');
  });
else
  return res.redirect('/users/login');
});

router.get('/:tarea_id/eliminarTarea', function(req, res) {
  models.Task.destroy({
    where: {
      id: req.params.tarea_id
    }
  }).then(function() {
    res.redirect('/');
  });
});

/*
router.get('/tareas', function(req, res) {
  models.Autor.findAll({
      //attributes: ['id'],
      //attributes: ['nombre']
//    where: { nombre: 'Antonio' }
  }).then(function(autores) {
if (req.user)
    res.render('autores.html', {
      title: 'Express: Autores',
      user: req.user
    });
else
    res.render('autores.html', {
      title: 'Express: Autores',
      user: undefined
    });
  });
});

router.get('/crearTarea', function(req, res) {
if (req.user)
  res.render('crear', { title: 'Express: Crear Autores', user: req.user });
else
  res.render('crear', { title: 'Express: Crear Autores', user: undefined });
});

router.post('/crearAutores', function(req, res) {
  models.Autor.create({
    nombre: req.body.nombre
  }).then(function() {
    res.redirect('/');
  });
});

router.get('/:tarea_id/eliminar', function(req, res) {
  models.Autor.destroy({
    where: {
      id: req.params.tarea_id
    }
  }).then(function() {
    res.redirect('/');
  });
});

router.get('/:autor_id/editar', function(req, res) {
if (req.user)
  res.render('editar', {
    title: 'Express: Editar Tareas de Autor',
    id: req.params.autor_id,
    user: req.user
  });
else
  res.render('editar', {
    title: 'Express: Editar Tareas de Autor',
    id: req.params.autor_id,
    user: undefined
  });
});

router.post('/:tarea_id/editarTarea', function(req, res) {
// https://stackoverflow.com/questions/26581715/sequelize-update-does-not-work-anymore-missing-where-attribute-in-the-options
//var values = { nombre: req.body.nombre };
//var selector = { where: { id: req.params.autor_id } };
    //values, selector
  models.Autor.update(
  {nombre: req.body.nombre},
  {
    where: {
      id: req.params.tarea_id
    }
  }).then(function() {
    res.redirect('/');
  });
});

module.exports = router;*/
