var models  = require('../models');
var express = require('express');
var router  = express.Router();

/*var esAutenticado = function (req, res, next) {
	if (req.isAuthenticated())
		return next();
	res.redirect('/');
}*/
function loggedIn(req, res, next) {
	if (req.user)
		return next();
	// if the user is not authenticated then redirect him to the login page
	//res.redirect('/');
	res.render('index', { title: 'Express', user: undefined });
}

/*router.get('/', function(req, res) {
  res.render('index', { title: 'Express' });
});*/
/*router.get('/', loggedIn, function(req, res, next) {
  res.render('index', { title: 'Express', user: req.user });
//console.log(req.user);
});*/
router.get('/', function(req, res) {
if (req.user)
  res.render('index', { title: 'Express', user: req.user });
else
  res.render('index', { title: 'Express', user: undefined });
//console.log(req.user);
});

router.get('/autores', function(req, res) {
  models.Autor.findAll({
      //attributes: ['id'],
      //attributes: ['nombre']
//    where: { nombre: 'Antonio' }
  }).then(function(autores) {

var totalAutores = autores.length,
    pageSize = 4,
    pageCount = Math.ceil(totalAutores/4),
    currentPage = 1,
    Autores = [],
    autoresArrays = [], 
    autoresList = [];

    for (var i = 0; i < totalAutores; i++) {
	Autores.push(autores[i]);
    }

    //split list into groups
    while (Autores.length > 0) {
	autoresArrays.push(Autores.splice(0, pageSize));
    }

    //set current page if specifed as get variable (eg: /?page=2)
    if (typeof req.query.page !== 'undefined') {
	currentPage = +req.query.page;
    }

    //show list of students from group
    autoresList = autoresArrays[+currentPage - 1];

if (req.user)
    res.render('autores.html', {
      title: 'Express: Autores',
      //autores: autores
      Autores: autoresList,
      pageSize: pageSize,
      pageCount: pageCount,
      currentPage: currentPage,
      user: req.user
    });
else
    res.render('autores.html', {
      title: 'Express: Autores',
      //autores: autores
      Autores: autoresList,
      pageSize: pageSize,
      pageCount: pageCount,
      currentPage: currentPage,
      user: undefined
    });
//console.log(autores.length);
//console.log(autores[0]);
  });
});

router.get('/crear', function(req, res) {
if (req.user)
  res.render('crear', { title: 'Express: Crear Autores', user: req.user });
else
  res.render('crear', { title: 'Express: Crear Autores', user: undefined });
});

router.post('/crearAutores', function(req, res) {
  models.Autor.create({
    nombre: req.body.nombre
  }).then(function() {
    res.redirect('/');
  });
});

router.get('/:autor_id/eliminar', function(req, res) {
  models.Autor.destroy({
    where: {
      id: req.params.autor_id
    }
  }).then(function() {
    res.redirect('/');
  });
});

router.get('/:autor_id/editar', function(req, res) {
if (req.user)
  res.render('editar', {
    title: 'Express: Editar Autores',
    id: req.params.autor_id,
    user: req.user
  });
else
  res.render('editar', {
    title: 'Express: Editar Autores',
    id: req.params.autor_id,
    user: undefined
  });
});

/*router.post('/:autor_id/editarAutor', function(req, res) {
  models.Autor.findAll({
    where: {
      id: req.params.autor_id
    }
  }).then(function(autores) {
    if(autores){
      autores.update({
      //autores.updateAttributes({
        nombre: req.body.nombre
      }).then(function(autores) {
        res.redirect('/');
      });
    }
  });
});*/

router.post('/:autor_id/editarAutor', function(req, res) {
// https://stackoverflow.com/questions/26581715/sequelize-update-does-not-work-anymore-missing-where-attribute-in-the-options
//var values = { nombre: req.body.nombre };
//var selector = { where: { id: req.params.autor_id } };
    //values, selector
  models.Autor.update(
  {nombre: req.body.nombre},
  {
    where: {
      id: req.params.autor_id
    }
  }).then(function() {
    res.redirect('/');
  });
});

module.exports = router;
